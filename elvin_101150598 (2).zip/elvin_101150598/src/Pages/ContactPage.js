import React from 'react'
import ContactItem from '../Components/ContactItem';
import phone from '../img/phone.svg';
import email from '../img/emailme.svg';
import location from '../img/location.svg';
import Tittle from '../Components/Tittle';
import emailjs from 'emailjs-com'


function ContactPage() {
    function sendEmail(e) {
        e.preventDefault();
    
        emailjs.sendForm('gmail', 'hatem', e.target,
         
        'user_GoFixTIHZdSTpzrHBI8Dv')
          .then((result) => {
              console.log(result.text);
          }, (error) => {
              console.log(error.text);
          });
          e.target.reset();
        }
    

    return (
        <div>
            <div className="title">
                <Tittle title={'About Me'} span={'About Me'} />
            </div>
            <div className="ContactPage">
                <div className="map-sect">
                <form onSubmit={sendEmail}>
                    <div className ="row pt-5 mx_auto">
                        <div className = "col -8 from group mx-auto">     
           <input type="hidden"/>
          <label style ={{margin:"2rem", color: "red"}}>Name</label>
          <input type="text" className ="from control" placeholder =
          "name" name="name" /> 
          </div>
          <div className = "col -8 from group mx-auto"> 
          <label style={{margin:"2rem", color: "red"}}>Email</label>
          <input type="email" className ="from control" placeholder ="email" name="email" />
          </div>
          <div className = "col -8 from group pt-2 mx-auto"> 
          <label style={{margin:"2rem", color: "red"}}>Subject</label>
          <input style ={{margin:"2rem"}} type="text" className ="from-control" placeholder ="Subject" name ="subject" /></div>
          <div className = "col -8 from group pt-2 mx-auto"> 
          <label style={{margin:"2rem", color: "red", textAlign:"start"}}>Message</label>
          
          <textarea style ={{margin:"1rem"}} name="message" className ="from-control" id= " " cols ="30" rows ="8" name ="message" /></div>
          <input type="submit" value="Send" /> 
          </div>
          
        </form>
                </div>
                <div className="contact-sect">
                    <ContactItem icon={phone} text1={'+1 647 532 85 36'} title={'Phone'}/>
                    <ContactItem icon={email} text1={'e.hatemov@gmail.com'} text2={'elvin.hatamov@georgebrown.ca'} title={'Email'}/>
                    <ContactItem icon={location} text1={'141 Davisville Ave, Toronto, ON, Canada'} text2={'United Kingdom'} title={'Address'}/>
                </div>
            </div>
        </div>
    )
}


export default ContactPage;
