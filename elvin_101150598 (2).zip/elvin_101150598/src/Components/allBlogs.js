import blog1 from '../img/blogs/LinkedIn.jpeg';
import blog2 from '../img/blogs/git.png';
import blog3 from '../img/blogs/twitter.jpg';
import blog4 from '../img/blogs/fb.jpg';


const blogs = [
    {
        id: 1,
        image: blog1,
        title: 'Linkedin account',
        link: 'https://www.linkedin.com/in/elvin-hatamov-897746121/',
        date : '21',
        month: 'Mar',
        year: '2020'
    },
    {
        id: 2,
        image: blog4,
        title: 'Facebook account',
        link: 'https://www.facebook.com/elvin.hatemi/',
        date : '09',
        month: 'Dec',
        year: '2019'
    },
    {
        id: 3,
        image: blog3,
        title: 'Twetter account',
        link: 'https://twitter.com/home',
        date : '15',
        month: 'Jun',
        year: '2018'
    },
    
    
    
    {
        id: 7,
        image: blog2,
        title: 'Github',
        link: 'https://github.com/e150598',
        date : '09',
        month: 'Sep',
        year: '2019'
    },
    
];

export default blogs;