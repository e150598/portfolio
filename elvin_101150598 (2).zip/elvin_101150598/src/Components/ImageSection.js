import React from 'react';
import about from '../img/about.jpeg';
import data from '../Components/elvin.PDF'
import DocViewer from "react-doc-viewer";
import { Button } from 'react-bootstrap';

function readDoc(){
    const docs =[require('./elvin.PDF')]
  return docs;
}


function ImageSection() {

    function downloadFile () {
        fetch(data)
            .then(response => {
                response.blob().then(blob => {
                    let url = window.URL.createObjectURL(blob);
                    let a = document.createElement('a');
                    a.href = url;
                    a.download = 'elvin.pdf';
                    a.click();
                });
                //window.location.href = response.url;
        });
    }
    function openFile () {
        fetch(data)
            .then(response => {
                response.blob().then(blob => {
                    let url = window.URL.createObjectURL(blob);
                    let a = document.createElement('a');
                    a.href = url;
                    a.open = 'elvin.pdf';
                    a.click();
                });
                //window.location.href = response.url;
        });
    }


    return (
        <div className="ImageSection">
            <div className="img">
                <img src={about}  alt=""/>
            </div>
            <div className="about-info">
                <h4>I am<span> Elvin Hatamov</span></h4>
                <p className="about-text">
                    Student at George Brown College. Studying Computer Programmer Analyist.
                </p>
                <div className="about-details">
                    <div className="left-section">
                        <p>Full Name</p>
                        <p>Languages</p>
                        <p>Address</p>
                        <p>Countries</p>
                    </div>
                    <div className="right-section">
                        <p>: Elvin Hatamov</p>
                     
                        <p>: English, Turkish, Russian</p>
                        <p>: 412-141 Davisville ave, Canada, Toronto, ON. M4S1G7</p>
                       
                    </div>
                </div>
            
                <Button variant = "primary"  onClick ={downloadFile}>Download Resume</Button> {' '}
                <Button variant ='primary' onClick ={openFile}>Open Resume</Button>

                
                
            </div>
        </div>
    )
}

export default ImageSection;
