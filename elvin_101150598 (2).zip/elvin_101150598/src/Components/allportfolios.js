import { text } from '@fortawesome/fontawesome-svg-core';
import port1 from '../img/portImages/elvin1.jpeg';
import port2 from '../img/portImages/elvin2.jpeg';
import port3 from '../img/portImages/elvin3.PNG';
import port4 from '../img/portImages/elvin4.png';
import port6 from '../img/portImages/port5.jpg';
import port7 from '../img/portImages/port6.jpg';
const portfolios = [
    {
        id: 1,
        category: 'Swift',
        image: port6,
        
        
        link1: "https://youtu.be/fAofp6zlc3s",
        link2: 'https://github.com/e150598/swift-location.git',
        icon2: 'GitHub',
        icon1: "Youtube",
        
        
        title: 'Practicing on Swift'
    },
    {
        id: 2,
        category: 'Capstone Project',
        image: port4,
        link1: "https://github.com/onurkazman/TurkTrade_Website.git",
        
        link2: 'https://turktrade.ca/',
        
        icon2: "WEB",
        icon1: "Git",
       
        title: 'Market Stock Web App'
    },
    {
        id: 3,
        category: 'Capstone Project',
        image:  port2,
        
        link2: 'https://github.com/onurkazman/TurkTrade_Mobile.git',
        
        icon2: 'GitHub',
        
        
        title: 'Markert Stock Mobil App',
        text: "TurkTrade is a mobil and web application which users can easly buy and sell stock"
    },
    {
        id: 4,
        category: 'Swift',
        image: port4,
        link1: "https://youtu.be/5tsUKnYq57Y",
        link2: 'https://github.com/e150598',
        icon1: 'G',
        icon2: 'Y',
       
        title: 'Navigation between pages on Swift'
    },
    {
        id: 5,
        category: 'React Js',
       image: port3,
        link2: 'https://github.com/e150598/101150598_comp3133_assig1.git',
        
        icon2: 'GitHub',
       
        title: 'Getting Started With React and MD'
    },
    
]

export default portfolios;